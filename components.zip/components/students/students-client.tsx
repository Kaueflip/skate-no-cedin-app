"use client"

import { useMemo }
    from "react"

import {
    Search,
    Download,
} from "lucide-react"

import type {
    Student,
} from "@/types/student"

import { GlassCard }
    from "@/components/ui/glass-card"

import { Input }
    from "@/components/ui/input"

import { AppButton }
    from "@/components/ui/app-button"

import { Badge }
    from "@/components/ui/badge"

import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table"

type Props = {

    initialStudents:
    Student[]
}

export function StudentsClient({
    initialStudents,
}: Props) {

    const students =
        useMemo(
            () => initialStudents,
            [initialStudents]
        )

    function exportStudentsCSV() {

        const headers = [
            "Nome",
            "Turma",
            "Turno",
            "Nível",
            "Responsável",
            "Contato",
        ]

        const rows =
            students.map(
                (student) => [

                    student.nome,

                    student.turma,

                    student.turno,

                    student.nivel,

                    student.responsavel_nome || "",

                    student.responsavel_contato || "",
                ]
            )

        const csvContent = [

            headers.join(","),

            ...rows.map(
                (row) =>
                    row.join(",")
            ),
        ].join("\n")

        const blob =
            new Blob(
                [
                    "\uFEFF",
                    csvContent,
                ],
                {
                    type:
                        "text/csv;charset=utf-8;",
                }
            )

        const url =
            URL.createObjectURL(
                blob
            )

        const a =
            document.createElement(
                "a"
            )

        a.href = url

        a.download =
            "alunos.csv"

        a.click()

        URL.revokeObjectURL(
            url
        )
    }

    return (

        <GlassCard
            className="
        overflow-hidden

        p-0
      "
        >

            <div className="
        flex
        flex-col
        gap-4

        border-b
        border-border

        p-6

        md:flex-row
        md:items-center
        md:justify-between
      ">

                <div className="
          relative

          w-full

          md:max-w-sm
        ">

                    <Search
                        className="
              absolute
              left-4
              top-1/2

              h-4
              w-4

              -translate-y-1/2

              text-muted
            "
                    />

                    <Input
                        placeholder="
              Buscar alunos...
            "
                        className="
              pl-11
            "
                    />

                </div>

                <AppButton
                    variant="secondary"
                    onClick={
                        exportStudentsCSV
                    }
                >

                    <Download
                        className="
              h-4
              w-4
            "
                    />

                    Exportar CSV

                </AppButton>

            </div>

            <Table>

                <TableHeader>

                    <TableRow>

                        <TableHead>
                            Nome
                        </TableHead>

                        <TableHead>
                            Turma
                        </TableHead>

                        <TableHead>
                            Turno
                        </TableHead>

                        <TableHead>
                            Nível
                        </TableHead>

                        <TableHead>
                            Responsável
                        </TableHead>

                    </TableRow>

                </TableHeader>

                <TableBody>

                    {students.map(
                        (student) => (

                            <TableRow
                                key={student.id}
                            >

                                <TableCell
                                    className="
                    font-medium
                  "
                                >

                                    {student.nome}

                                </TableCell>

                                <TableCell>

                                    {student.turma}

                                </TableCell>

                                <TableCell>

                                    {student.turno}

                                </TableCell>

                                <TableCell>

                                    <Badge
                                        variant="secondary"
                                    >

                                        {student.nivel}

                                    </Badge>

                                </TableCell>

                                <TableCell>

                                    {
                                        student
                                            .responsavel_nome
                                    }

                                </TableCell>

                            </TableRow>
                        )
                    )}

                </TableBody>

            </Table>

        </GlassCard>
    )
}