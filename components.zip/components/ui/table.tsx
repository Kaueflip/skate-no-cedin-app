"use client"

import * as React
  from "react"

import { cn }
  from "@/lib/utils"

function Table({
  className,
  ...props
}: React.ComponentProps<"table">) {

  return (

    <div
      data-slot="table-container"
      className="
        relative
        w-full

        overflow-x-auto
      "
    >

      <table
        data-slot="table"
        className={cn(
          `
            w-full
            caption-bottom

            text-sm
          `,
          className
        )}
        {...props}
      />

    </div>
  )
}

function TableHeader({
  className,
  ...props
}: React.ComponentProps<"thead">) {

  return (

    <thead
      data-slot="table-header"
      className={cn(
        `
          border-b
          border-border
        `,
        className
      )}
      {...props}
    />
  )
}

function TableBody({
  className,
  ...props
}: React.ComponentProps<"tbody">) {

  return (

    <tbody
      data-slot="table-body"
      className={cn(
        `
          [&_tr:last-child]:border-0
        `,
        className
      )}
      {...props}
    />
  )
}

function TableFooter({
  className,
  ...props
}: React.ComponentProps<"tfoot">) {

  return (

    <tfoot
      data-slot="table-footer"
      className={cn(
        `
          border-t
          border-border

          bg-card

          font-medium
        `,
        className
      )}
      {...props}
    />
  )
}

function TableRow({
  className,
  ...props
}: React.ComponentProps<"tr">) {

  return (

    <tr
      data-slot="table-row"
      className={cn(
        `
          border-b
          border-border

          transition-colors

          hover:bg-white/60

          dark:hover:bg-white/3
        `,
        className
      )}
      {...props}
    />
  )
}

function TableHead({
  className,
  ...props
}: React.ComponentProps<"th">) {

  return (

    <th
      data-slot="table-head"
      className={cn(
        `
          h-12

          px-4

          text-left
          align-middle

          text-xs
          font-semibold
          uppercase

          tracking-[0.12em]

          text-muted
        `,
        className
      )}
      {...props}
    />
  )
}

function TableCell({
  className,
  ...props
}: React.ComponentProps<"td">) {

  return (

    <td
      data-slot="table-cell"
      className={cn(
        `
          px-4
          py-4

          align-middle

          text-foreground
        `,
        className
      )}
      {...props}
    />
  )
}

function TableCaption({
  className,
  ...props
}: React.ComponentProps<"caption">) {

  return (

    <caption
      data-slot="table-caption"
      className={cn(
        `
          mt-4

          text-sm

          text-muted
        `,
        className
      )}
      {...props}
    />
  )
}

export {
  Table,
  TableHeader,
  TableBody,
  TableFooter,
  TableHead,
  TableRow,
  TableCell,
  TableCaption,
}