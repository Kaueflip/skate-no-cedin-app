"use client"

import * as React from "react"
import { Dialog as DialogPrimitive } from "radix-ui"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { X, XIcon } from "lucide-react"

function Dialog({
  ...props
}: React.ComponentProps<typeof DialogPrimitive.Root>) {
  return <DialogPrimitive.Root data-slot="dialog" {...props} />
}

function DialogTrigger({
  ...props
}: React.ComponentProps<typeof DialogPrimitive.Trigger>) {
  return <DialogPrimitive.Trigger data-slot="dialog-trigger" {...props} />
}

function DialogPortal({
  ...props
}: React.ComponentProps<typeof DialogPrimitive.Portal>) {
  return <DialogPrimitive.Portal data-slot="dialog-portal" {...props} />
}

function DialogClose({
  ...props
}: React.ComponentProps<typeof DialogPrimitive.Close>) {
  return <DialogPrimitive.Close data-slot="dialog-close" {...props} />
}

function DialogOverlay({
  className,
  ...props
}: React.ComponentProps<
  typeof DialogPrimitive.Overlay
>) {

  return (

    <DialogPrimitive.Overlay
      data-slot="dialog-overlay"
      className={cn(
        `
          fixed
          inset-0
          z-50

          bg-black/40

          backdrop-blur-sm

          data-[state=open]:animate-in
          data-[state=closed]:animate-out

          data-[state=closed]:fade-out-0
          data-[state=open]:fade-in-0
        `,
        className
      )}
      {...props}
    />
  )
}

function DialogContent({
  className,
  children,
  ...props
}: React.ComponentProps<
  typeof DialogPrimitive.Content
>) {

  return (

    <DialogPortal>

      <DialogOverlay />

      <DialogPrimitive.Content
        data-slot="dialog-content"
        className={cn(
          `
            fixed
            left-[50%]
            top-[50%]
            z-50

            grid
            w-full
            max-w-lg

            translate-x-[-50%]
            translate-y-[-50%]

            gap-4

            rounded-4xl

            border
            border-border

            bg-card

            p-6

            text-foreground

            shadow-2xl

            backdrop-blur-2xl

            duration-200

            data-[state=open]:animate-in
            data-[state=closed]:animate-out

            data-[state=closed]:fade-out-0
            data-[state=open]:fade-in-0

            data-[state=closed]:zoom-out-95
            data-[state=open]:zoom-in-95

            data-[state=closed]:slide-out-to-left-1/2
            data-[state=closed]:slide-out-to-top-[48%]

            data-[state=open]:slide-in-from-left-1/2
            data-[state=open]:slide-in-from-top-[48%]
          `,
          className
        )}
        {...props}
      >

        {children}

        <DialogPrimitive.Close
          className="
            absolute
            right-4
            top-4

            flex
            h-9
            w-9
            items-center
            justify-center

            rounded-xl

            text-muted

            transition-all

            hover:bg-white/70
            hover:text-foreground

            dark:hover:bg-white/[0.04]

            focus-visible:ring-4
            focus-visible:ring-ring

            disabled:pointer-events-none
          "
        >

          <X className="
            h-4
            w-4
          " />

          <span className="sr-only">

            Fechar

          </span>

        </DialogPrimitive.Close>

      </DialogPrimitive.Content>

    </DialogPortal>
  )
}

function DialogHeader({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="dialog-header"
      className={cn("flex flex-col gap-2", className)}
      {...props}
    />
  )
}

function DialogFooter({
  className,
  showCloseButton = false,
  children,
  ...props
}: React.ComponentProps<"div"> & {
  showCloseButton?: boolean
}) {
  return (
    <div
      data-slot="dialog-footer"
      className={cn(
        "-mx-4 -mb-4 flex flex-col-reverse gap-2 rounded-b-xl border-t bg-muted/50 p-4 sm:flex-row sm:justify-end",
        className
      )}
      {...props}
    >
      {children}
      {showCloseButton && (
        <DialogPrimitive.Close asChild>
          <Button variant="outline">Close</Button>
        </DialogPrimitive.Close>
      )}
    </div>
  )
}

function DialogTitle({
  className,
  ...props
}: React.ComponentProps<
  typeof DialogPrimitive.Title
>) {

  return (

    <DialogPrimitive.Title
      data-slot="dialog-title"
      className={cn(
        `
          text-xl
          font-bold
          tracking-tight

          text-foreground
        `,
        className
      )}
      {...props}
    />
  )
}

function DialogDescription({
  className,
  ...props
}: React.ComponentProps<
  typeof DialogPrimitive.Description
>) {

  return (

    <DialogPrimitive.Description
      data-slot="dialog-description"
      className={cn(
        `
          text-sm

          text-muted
        `,
        className
      )}
      {...props}
    />
  )
}

export {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogOverlay,
  DialogPortal,
  DialogTitle,
  DialogTrigger,
}
