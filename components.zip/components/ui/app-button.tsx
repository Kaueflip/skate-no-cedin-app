"use client"

import type {
    ButtonHTMLAttributes,
    ReactNode,
} from "react"

import { Loader2 }
    from "lucide-react"

import { cn }
    from "@/lib/utils"

type Variant =
    | "primary"
    | "secondary"
    | "ghost"

type Props =
    ButtonHTMLAttributes<HTMLButtonElement> & {
        loading?: boolean

        children: ReactNode

        variant?: Variant
    }

export function AppButton({
    loading,
    children,
    className,
    disabled,
    variant = "primary",
    ...props
}: Props) {

    const variants = {

        primary: `
      bg-primary
      text-primary-foreground

      hover:bg-accent-hover

      shadow-sm
    `,

        secondary: `
      border
      border-border

      bg-card

      text-foreground

      hover:bg-white/70

      dark:hover:bg-white/[0.04]
    `,

        ghost: `
      bg-transparent

      text-foreground

      hover:bg-white/60

      dark:hover:bg-white/[0.04]
    `,
    }

    return (

        <button
            disabled={
                disabled || loading
            }
            className={cn(
                `
          inline-flex
          items-center
          justify-center
          gap-2

          rounded-2xl

          px-6
          py-3

          text-sm
          font-semibold

          transition-all

          outline-none

          focus-visible:ring-4
          focus-visible:ring-ring

          active:scale-[0.985]

          disabled:pointer-events-none
          disabled:opacity-50

          cursor-pointer
        `,

                variants[variant],

                className
            )}
            {...props}
        >

            {loading && (

                <Loader2
                    className="
            h-4
            w-4

            animate-spin
          "
                />

            )}

            {children}

        </button>
    )
}