"use client"

import * as React from "react"
import { Select as SelectPrimitive } from "radix-ui"

import { cn } from "@/lib/utils"
import { ChevronDownIcon, CheckIcon, ChevronUpIcon, ChevronDown, Check } from "lucide-react"

function Select({
  ...props
}: React.ComponentProps<typeof SelectPrimitive.Root>) {
  return <SelectPrimitive.Root data-slot="select" {...props} />
}

function SelectGroup({
  className,
  ...props
}: React.ComponentProps<typeof SelectPrimitive.Group>) {
  return (
    <SelectPrimitive.Group
      data-slot="select-group"
      className={cn("scroll-my-1 p-1", className)}
      {...props}
    />
  )
}

function SelectValue({
  ...props
}: React.ComponentProps<typeof SelectPrimitive.Value>) {
  return <SelectPrimitive.Value data-slot="select-value" {...props} />
}

function SelectTrigger({
  className,
  children,
  ...props
}: React.ComponentProps<
  typeof SelectPrimitive.Trigger
>) {

  return (

    <SelectPrimitive.Trigger
      data-slot="select-trigger"
      className={cn(
        `
          flex
          h-11
          w-full
          items-center
          justify-between
          gap-2

          rounded-2xl

          border
          border-border

          bg-input

          px-4

          text-sm
          text-foreground

          shadow-sm

          outline-none

          transition-all

          placeholder:text-muted

          focus-visible:ring-4
          focus-visible:ring-ring

          disabled:cursor-not-allowed
          disabled:opacity-50

          [&>span]:line-clamp-1
        `,
        className
      )}
      {...props}
    >

      {children}

      <SelectPrimitive.Icon
        asChild
      >

        <ChevronDown
          className="
            h-4
            w-4

            text-muted

            opacity-80
          "
        />

      </SelectPrimitive.Icon>

    </SelectPrimitive.Trigger>
  )
}

function SelectContent({
  className,
  children,
  position = "popper",
  ...props
}: React.ComponentProps<
  typeof SelectPrimitive.Content
>) {

  return (

    <SelectPrimitive.Portal>

      <SelectPrimitive.Content
        data-slot="select-content"
        position={position}
        className={cn(
          `
            relative
            z-50

            min-w-[8rem]

            overflow-hidden

            rounded-2xl

            border
            border-border

            bg-card

            text-foreground

            shadow-xl

            backdrop-blur-2xl

            data-[state=open]:animate-in
            data-[state=closed]:animate-out

            data-[state=closed]:fade-out-0
            data-[state=open]:fade-in-0

            data-[state=closed]:zoom-out-95
            data-[state=open]:zoom-in-95

            data-[side=bottom]:slide-in-from-top-2
            data-[side=left]:slide-in-from-right-2
            data-[side=right]:slide-in-from-left-2
            data-[side=top]:slide-in-from-bottom-2
          `,
          position === "popper" &&
          `
              data-[side=bottom]:translate-y-1
              data-[side=left]:-translate-x-1
              data-[side=right]:translate-x-1
              data-[side=top]:-translate-y-1
            `,
          className
        )}
        {...props}
      >

        <SelectPrimitive.Viewport
          className={cn(
            `
              p-1
            `,
            position === "popper" &&
            `
                h-[var(--radix-select-trigger-height)]
                min-w-[var(--radix-select-trigger-width)]
              `
          )}
        >

          {children}

        </SelectPrimitive.Viewport>

      </SelectPrimitive.Content>

    </SelectPrimitive.Portal>
  )
}

function SelectLabel({
  className,
  ...props
}: React.ComponentProps<typeof SelectPrimitive.Label>) {
  return (
    <SelectPrimitive.Label
      data-slot="select-label"
      className={cn("px-1.5 py-1 text-xs text-muted-foreground", className)}
      {...props}
    />
  )
}

function SelectItem({
  className,
  children,
  ...props
}: React.ComponentProps<
  typeof SelectPrimitive.Item
>) {

  return (

    <SelectPrimitive.Item
      data-slot="select-item"
      className={cn(
        `
          relative
          flex
          w-full
          cursor-pointer
          select-none
          items-center
          gap-2

          rounded-xl

          px-3
          py-2

          text-sm
          text-foreground

          outline-none

          transition-colors

          focus:bg-primary
          focus:text-primary-foreground

          data-[disabled]:pointer-events-none
          data-[disabled]:opacity-50
        `,
        className
      )}
      {...props}
    >

      <span
        className="
          absolute
          right-3

          flex
          h-3.5
          w-3.5
          items-center
          justify-center
        "
      >

        <SelectPrimitive.ItemIndicator>

          <Check className="
            h-4
            w-4
          " />

        </SelectPrimitive.ItemIndicator>

      </span>

      <SelectPrimitive.ItemText>

        {children}

      </SelectPrimitive.ItemText>

    </SelectPrimitive.Item>
  )
}

function SelectSeparator({
  className,
  ...props
}: React.ComponentProps<typeof SelectPrimitive.Separator>) {
  return (
    <SelectPrimitive.Separator
      data-slot="select-separator"
      className={cn("pointer-events-none -mx-1 my-1 h-px bg-border", className)}
      {...props}
    />
  )
}

function SelectScrollUpButton({
  className,
  ...props
}: React.ComponentProps<typeof SelectPrimitive.ScrollUpButton>) {
  return (
    <SelectPrimitive.ScrollUpButton
      data-slot="select-scroll-up-button"
      className={cn(
        "z-10 flex cursor-default items-center justify-center bg-popover py-1 [&_svg:not([class*='size-'])]:size-4",
        className
      )}
      {...props}
    >
      <ChevronUpIcon
      />
    </SelectPrimitive.ScrollUpButton>
  )
}

function SelectScrollDownButton({
  className,
  ...props
}: React.ComponentProps<typeof SelectPrimitive.ScrollDownButton>) {
  return (
    <SelectPrimitive.ScrollDownButton
      data-slot="select-scroll-down-button"
      className={cn(
        "z-10 flex cursor-default items-center justify-center bg-popover py-1 [&_svg:not([class*='size-'])]:size-4",
        className
      )}
      {...props}
    >
      <ChevronDownIcon
      />
    </SelectPrimitive.ScrollDownButton>
  )
}

export {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectScrollDownButton,
  SelectScrollUpButton,
  SelectSeparator,
  SelectTrigger,
  SelectValue,
}
